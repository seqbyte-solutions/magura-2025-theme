
<img src="<?= MAGURA_2025_THEME_URL ?>/assets/img/map_v5.svg" alt="">