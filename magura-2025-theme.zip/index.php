<?php

namespace Magura2025;

$template_handler = $GLOBALS['magura2025']->get_template_handler();
$template_handler->render();